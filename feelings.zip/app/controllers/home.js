module.exports.index = function(app, req, res){
	if (!req.session.loggedin) {
		res.redirect('/form_login');
		return;
	}

	var MongoClient = require('mongodb').MongoClient;
	var url = "mongodb://localhost:27017/";

	MongoClient.connect(url, {useNewUrlParser: true },
	function(err, db) {
		if (err) {throw err;}
		var dbo = db.db("feelings");
		dbo.collection('postagem').find().sort({data_postagem: -1}).toArray(function(err, dados_postagens){
			dbo.collection('usuario').find().toArray(function(err, dados_usuarios){
				res.render('index', {postagens: dados_postagens, usuarios: dados_usuarios, id_usuario: req.session._id});
			});
		});
	});
}

// module.exports.form_consultar = function(app, req, res){
// 	var MongoClient = require('mongodb').MongoClient;
// 	var url = "mongodb://localhost:27017/";

// 	MongoClient.connect(url, {useNewUrlParser: true }, 
// 	function(err, db) {
// 		if (err) {throw err;}
// 		var dbo = db.db("feelings");
// 		var ObjectID = require('mongodb').ObjectID;
// 		var o_id = ObjectID(req.session._id);
// 		dbo.collection('usuario').find({_id: o_id}).toArray(function(err, dados_usuario){
// 			res.render('form_consultar', {usuario: dados_usuario});
// 		});
// 	});
// }

// module.exports.consultar = function(app, req, res){
// 	var MongoClient = require('mongodb').MongoClient;
// 	var url = "mongodb://localhost:27017/";

// 	MongoClient.connect(url, {useNewUrlParser: true },
// 	function(err, db) {
// 		if (err) {throw err;}
// 		var dbo = db.db("baseClientes");
// 		var find = req.body.procurado; // recebe o id do cliente pesquisado pelo usuário

// 		var ObjectID = require('mongodb').ObjectID; // faz a requisição do ObjectID e executa ao mesmo tempo
// 		var o_id = ObjectID(find); // a variável o_id recebe o id do cliente pesquisado no formato ObjectID (utilizado no banco de dados do mongo)

// 		dbo.collection('clientes').find({ _id: o_id}).toArray(function(err, result){ // é feita uma busca na coleção clientes de um id igual ao pesquisado pelo usuário. O resultado é transformado em vetor
// 			res.render('form_consultar', {clientes: result}); // a página de consulta é renderizada e a variável clientes recebe um vetor com o cliente pesquisado
// 		});
// 	});
// }