var app = require('./config/server');

app.listen(3000,function(){
	console.log('Servidor ON');
});